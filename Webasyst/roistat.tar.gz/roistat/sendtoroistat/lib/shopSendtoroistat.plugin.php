<?php


class shopSendtoroistatPlugin extends shopPlugin
{
    public function sendOrderDataToRoistat($data)
    {
        $order_id = $data['order_id'];
        $order_model = new shopOrderModel();
        $data = $order_model->getOrder($order_id);

        $total = $data['total'];
        $currency = $data['currency'];
        $payment = $data['params']['payment_name'];
        $shipping = $data['params']['shipping_name'];
        $city = $data['params']['shipping_address.city'];
        $addr = $data['params']['shipping_address.street'];

        $title = "Заказ #{$order_id}";
        $name = $data['contact']['name'];
        $email = $data['contact']['email'];
        $phone = $data['contact']['phone'];
        $customer_comment = $data['comment'];

        $items = $data['items'];
        $items_info = "";
        foreach ($items as $item) {
            $p_name = $item['name'];
            $p_price = $item['price'];
            $p_quantity = $item['quantity'];

            $items_info .= "\t{$p_name} x {$p_quantity} по {$p_price};" . PHP_EOL;
        }

        $comment = '';
        // $comment 	= "Товары: {$items_info}" . PHP_EOL;
        $comment .= "Итого: {$total} {$currency};" . PHP_EOL;
        $comment .= "Оплата: {$payment};" . PHP_EOL;
        $comment .= "Город: {$city};" . PHP_EOL;
        $comment .= "Адрес: {$addr};" . PHP_EOL;
        $form_title = 'Корзина';
        if (!$shipping) {
            $title = 'Купить в 1 клик '."#{$order_id}";
            $form_title = 'Купить в 1 клик';
        }
        $items_info=html_entity_decode($items_info);
        $RoistatCoockie = isset($_COOKIE['roistat_visit']) ? $_COOKIE['roistat_visit'] : null;
        $RoistatMarker = isset($_COOKIE['roistat_marker']) ? $_COOKIE['roistat_marker'] : 'прямой заход';
        $roistatData = array(
            'roistat' => $RoistatCoockie,
            'key' => 'MjgzMjA6MzIxNzA6N2QyMjJjYjRiZDkyM2JjYTQxYTNkMTlmODY3YjgwODU=',
            'title' => $title,
            'comment' => '',
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'is_need_callback' => '0',
            'fields' => array(
                'OPPORTUNITY' => $total,
                'UF_CRM_1484133071' => $RoistatCoockie,
                'UF_CRM_1513865846' => $RoistatMarker,
                'UF_CRM_1513865960' => $form_title,
                'UF_CRM_1509388379' => "{$city} {$addr}",
                'UF_CRM_1509084352' => $shipping,
                'UF_CRM_1513866154' => $items_info,
                'UF_CRM_1513866366' => $customer_comment,
                'UF_CRM_1508932227' => $payment
            ),
        );
        $roistatData['fields'] = array_filter($roistatData['fields'], function ($element) {
            return !empty(trim($element));
        });

        file_get_contents("https://cloud.roistat.com/api/proxy/1.0/leads/add?" . http_build_query($roistatData));

    }

}