<?php

return array(
    'name' => 'Отправка данных в ROISTAT',
    // 'img'  => 'img/image.png',
    'description' => 'Отправляет данные заказа в Roistat',
    'version' => '1.0',
    'handlers' => array(
    	'order_action.create' => 'sendOrderDataToRoistat'
    )
);