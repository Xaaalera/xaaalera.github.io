<?php
$data = json_decode(trim(file_get_contents('php://input')), true);
file_put_contents('webhook-log.txt', "{$data['caller']} -> {$data['callee']->$data['callee']}\n", FILE_APPEND); // В $data будет массив ключ => значение с информацией о звонке, описанной выше